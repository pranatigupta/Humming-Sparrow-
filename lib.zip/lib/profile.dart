import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

import 'dart:ui';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

import 'package:flutter/services.dart';
import 'package:internship/main.dart';
import 'package:internship/video.dart';




class ProfileEdit extends StatefulWidget {
  @override
  _ProfileEditState createState() => _ProfileEditState();
}

class _ProfileEditState extends State<ProfileEdit> {
  File _image;
  _imgFromCamera() async {
  PickedFile image = await ImagePicker().getImage(
    source: ImageSource.camera, imageQuality: 50
  );

  setState(() {
    _image = File(image.path);
  });
}

_imgFromGallery() async {
  PickedFile image = await  ImagePicker().getImage(
      source: ImageSource.gallery, imageQuality: 50
  );

  setState(() {
    _image = File(image.path);
  });
}

void _showPicker(context) {
  showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Container(
            child: new Wrap(
              children: <Widget>[
                new ListTile(
                    leading: new Icon(Icons.photo_library),
                    title: new Text('Photo Library'),
                    onTap: () {
                      _imgFromGallery();
                      Navigator.of(context).pop();
                    }),
                new ListTile(
                  leading: new Icon(Icons.photo_camera),
                  title: new Text('Camera'),
                  onTap: () {
                    _imgFromCamera();
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          ),
        );
      }
    );
}

final locationController = TextEditingController();
final pincodeController = TextEditingController();
final genderController = TextEditingController();
final whatsappController = TextEditingController();
final emailController = TextEditingController();
final dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: HexColor("1a322b"),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      drawer: Drawer(
        
        child: ListView(
    children: <Widget>[
      Container(
        height: 200.0,
        color: HexColor("1a322b"),
      ),
      ListTile(
        title: Text("Home"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => MyHomePage()));
        },
      ),
      ListTile(
        title: Text("Videos"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => Video()));
        },
      ),
       ListTile(
        title: Text("Profile"),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
    ],
  ),
      ),
      body: SingleChildScrollView(
              child: Center(
                  child: Column(
                  children: [
                    Container(
                      width: 500,
                      padding: EdgeInsets.symmetric(vertical:20.0),
                      color: Colors.grey[300],
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 55,
                            backgroundColor: Colors.orange[600],
                            child: _image != null
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(50),
                                    child: Image.file(
                                      _image,
                                      width: 100,
                                      height: 100,
                                      fit: BoxFit.fitHeight,
                                    ),
                                  )
                                : Container(
                                    decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(50)),
                                    width: 100,
                                    height: 100,
                                    child: Icon(
                                      Icons.camera_alt,
                                      color: Colors.grey[800],
                                    ),
                                  ),
                          ),
                       
                      SizedBox(height:5.0),
                      Text("Pranati Gupta",
                      style:TextStyle(color: Colors.orange[600],fontWeight:FontWeight.bold, fontSize: 20),
                      ),
                      SizedBox(height:10.0),
                      TextButton(
                        
                        onPressed: (){
                          _showPicker(context);
                      },
                      child:Container(
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            "Edit Profile",
                            style: TextStyle(color: Colors.orange[600],fontSize: 13.0 ),
                          ),
                        ),
                      ),

                      ),
                       ],
                      ),
                    ),
                    SizedBox(height:30.0),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 35.0),
                    child: Column(
                      children: [
                        TextField(
                          controller: locationController,
                          keyboardType: TextInputType.multiline,
                          decoration: InputDecoration(
                            labelText: 'Location', 
                            hintText: 'xxxxxxxxxxxxxxxxxxxxxx',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            )
                            ),
                        ),
                      
                    SizedBox(height: 10.0),
                    TextField(
                      controller: pincodeController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: InputDecoration(labelText: 'Pincode',
                      hintText: 'xxxxxx',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            )
                      ),
                    ),
                    SizedBox(height:10.0),
                    TextField(
                 readOnly: true,
                 controller: dateController,
                 decoration: InputDecoration(
                    labelText: 'Pick your Date',
                    hintText: 'dd-mm-yy',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            )
                ),
                 onTap: () async {
                var date =  await showDatePicker(
                      context: context, 
                      initialDate:DateTime.now(),
                      firstDate:DateTime(1900),
                      lastDate: DateTime(2100));
                dateController.text = date.toString().substring(0,10);      
         },
         ),
         SizedBox(height:10.0),
         TextField(
                      controller: genderController,
                      decoration: InputDecoration(labelText: 'Gender',
                      hintText: 'Female',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            )
                            ),
                    ),
                    SizedBox(height:10.0),
                    TextField(
                      controller: whatsappController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: InputDecoration(labelText: 'Whatsapp',
                      hintText: '+91-xxxxxxxxxx',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            )
                            ),
                    ),
                    SizedBox(height:10.0),
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: 'Email',
                      hintText: 'xxxxxxxx@gamil.com',
                            labelStyle: TextStyle(
                              color: Colors.grey[400],
                              fontWeight: FontWeight.bold

                            ),
                      )
                      
                    ),
                    ],
                    ),
                  ),
                  ],
                  ),
              )
      )

    );
  }
}