import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:internship/profile.dart';

import 'main.dart';

class Video extends StatefulWidget {
  @override
  _VideoState createState() => _VideoState();
}

class _VideoState extends State<Video> {

  List<String> headings=[
    "This is the haeding of related news or may be extended",
    "This is the haeding of related news or may be extended",
    "This is the haeding of related news or may be extended",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: HexColor("1a322b"),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      drawer: Drawer(
        
        child: ListView(
    children: <Widget>[
      Container(
        height: 200.0,
        color: HexColor("1a322b"),
      ),
      ListTile(
        title: Text("Home"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => MyHomePage()));
        },
      ),
      ListTile(
        title: Text("Videos",),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
       ListTile(
        title: Text("Profile"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => ProfileEdit()));
        },
      ),
    ],
  ),
      ),

      body:SingleChildScrollView(
          child: Column(
            children:<Widget>[
              Container(
                padding: EdgeInsets.symmetric(vertical:10.0),
                child: Text("Videos",style: TextStyle(fontSize: 20.0),),
              ),

              Container(
                height: 200,
                width: 400,  
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("lib/videoimage.png"),
                    fit: BoxFit.cover,
                    colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.5),                                                    
                    BlendMode.srcOver)
                    ),     
                ),
                child: Icon(Icons.play_arrow_rounded, color: Colors.white,size: 60.0,),
              ),
              SizedBox(height:20),

              Container(
                padding: EdgeInsets.symmetric(horizontal:15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal:10.0),
                      child: Text('This is the heading of the related news this is another',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                 
                SizedBox(height:5.0),
                Padding(
                  padding: const EdgeInsets.only(left:10.0),
                  child: Text('Date & Time here',
                  ),
                ),
                SizedBox(height:10.0),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal:10.0),
                  child: Text('This is the heading of the related news this is another Heading of the news',
                  overflow: TextOverflow.clip,
                  ),
                ),
                SizedBox(height:10.0),
                Container(
                 
                  alignment: Alignment.center,
                  
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary:Colors.grey[300],
                      padding: EdgeInsets.symmetric(horizontal:135.0),
                    ),
                    onPressed: (){

                    },
                    child: Text("Information",
                    style:TextStyle(fontWeight: FontWeight.bold,color: Colors.black
                    )
                    ),
                    ),
                )
                 ],
                ),
              ),

              Container(
        child: Padding(
          padding: EdgeInsets.all(16.0),
            child: Container(
            
            child: ListView.builder(
            shrinkWrap: true,
            itemCount: headings.length,
            itemBuilder: (context,index){
            return Card(
              
              elevation: 0.0,
                  child: Container(
                    padding: EdgeInsets.all(8),
                    child: Row(
                      children: <Widget>[
                        Container(
                          height: 70,
                          width: 120,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("lib/farmer.jpg"),
                              fit: BoxFit.cover
                              ),
                              
                              
                          )
                        ),
                        Container(
                          
                          padding: EdgeInsets.only(left:10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                           Container(
                             width: 200.0,
                           padding: EdgeInsets.only(bottom: 5.0),
                           child: Text(
                             headings[index],
                            
                             overflow: TextOverflow.clip,
                             style: TextStyle(
                               fontWeight: FontWeight.bold,

                             ),
                             ),
                             ),
                  
                           Row(
                               children:[
                                 Icon(Icons.calendar_today_rounded, color: Colors.grey,),
                                 Container(
                                   padding: EdgeInsets.only(right:10.0,left:5.0),
                                   child:Text(
                                     '14-05-2021',
                                     style: TextStyle(color: Colors.grey),
                                   )
                                   ),
                                   Container(
                                     color: Colors.orange[800],
                                     child:Padding(padding:EdgeInsets.symmetric(horizontal:15.0) ,
                                     child:Text(
                                       'Info',
                                       style: TextStyle(color: Colors.white),
                                     )
                                     )
                                   ),
                                   Container(
                                     padding: EdgeInsets.only(left: 10.0),
                                     child:Icon(Icons.bookmark_border),
                              
                                   )
                               ]
                             )
                            ],),
                        )
                      ]
                    ),
                  )
            );
            }
            ),
          ),
        ),
      )
            ]
          ),
      )
    );
  }
}