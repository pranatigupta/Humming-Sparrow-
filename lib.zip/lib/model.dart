

import 'package:flutter/cupertino.dart';

class News{
  String heading;
  String details;

  News({
    @required this.heading,
    @required this.details,
  });
}