import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:internship/model.dart';
import 'package:internship/profile.dart';
import 'package:internship/video.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: Colors.grey[300],
        textSelectionTheme: TextSelectionThemeData(cursorColor: Colors.grey[300])
      ),
       home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  final List<News> _news =[
    News(
      heading:'This is heading 1 and so on',
      details: 'This is the haeding of a realted news and this will go on like this'
    ),
    News(
      heading:'This is heading 1 and is delivered and so on',
      details: 'This is the haeding of a realted news and this will go on like this '
    ),
    News(
      heading:'This is heading 1 and is delivered and so on',
      details: 'This is the haeding of a realted news and this will go on like this '
    ),
    News(
      heading:'This is heading 1 and is delivered and so on',
      details: 'This is the haeding of a realted news and this will go on like this '
    ),
    News(
      heading:'This is heading 1 and new is delivered and so on',
      details: 'This is the haeding of a realted news and this will go on like this '
    ),
    News(
      heading:'This is heading 1 and is delivered and so on',
      details: 'This is the haeding of a realted news and this will go on like this '
    ),

  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: HexColor("1a322b"),
      ),
      drawer: Drawer(
        
        child: ListView(
    children: <Widget>[
      Container(
        height: 200.0,
        color: HexColor("1a322b"),
      ),
      ListTile(
        title: Text("Home"),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
      ListTile(
        title: Text("Videos"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => Video()));
        },
      ),
       ListTile(
        title: Text("Profile"),
        onTap: (){
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => ProfileEdit()));
        },
      ),
    ],
  ),
      ),
      body: Container(
        child: Padding(
          padding: EdgeInsets.all(16.0),
            child: Container(
            
            child: ListView.builder(
            shrinkWrap: true,
            itemCount: _news.length,
            itemBuilder: (context,index){
            return Card(
              
              elevation: 0.0,
                  child: Container(
                    padding: EdgeInsets.all(8),
                    child: Row(
                      children: <Widget>[
                        Container(
                          height: 110,
                          width: 110,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("lib/modi1.jpg"),
                              fit: BoxFit.cover
                              ),
                              borderRadius: BorderRadius.circular(12),
                              
                          )
                        ),
                        Container(
                          
                          padding: EdgeInsets.only(left:10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                           Container(
                             width: 200.0,
                           padding: EdgeInsets.only(bottom: 5.0),
                           child: Text(
                             _news[index].heading,
                            
                             overflow: TextOverflow.clip,
                             style: TextStyle(
                               fontWeight: FontWeight.bold,

                             ),
                             ),
                             ),
                           Container(
                             width: 200,
                               padding: EdgeInsets.only(bottom: 10.0),
                               child: Text(
                               _news[index].details,
                               overflow: TextOverflow.clip,
                               style: TextStyle(
                                 color: Colors.grey,

                               ),
                               ),
                             ),
                           Row(
                               children:[
                                 Icon(Icons.calendar_today_rounded, color: Colors.grey,),
                                 Container(
                                   padding: EdgeInsets.only(right:10.0,left:5.0),
                                   child:Text(
                                     '14-05-2021',
                                     style: TextStyle(color: Colors.grey),
                                   )
                                   ),
                                   Container(
                                     color: Colors.orange[800],
                                     child:Padding(padding:EdgeInsets.symmetric(horizontal:15.0) ,
                                     child:Text(
                                       'sports',
                                       style: TextStyle(color: Colors.white),
                                     )
                                     )
                                   ),
                                   Container(
                                     padding: EdgeInsets.only(left: 10.0),
                                     child:Icon(Icons.bookmark_border),
                              
                                   )
                               ]
                             )
                            ],),
                        )
                      ]
                    ),
                  )
            );
            }
            ),
          ),
        ),
      )
    );
  }
}

